/* This file is auto generated, version 202002191432 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#202002191432 SMP Wed Feb 19 19:37:23 UTC 2020"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 9.2.1 20200203 (Ubuntu 9.2.1-28ubuntu1)"
