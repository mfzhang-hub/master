var config = {
  zhongxingInboundUrl: "http://172.26.66.241/#/order-manage/storage",  // 中兴入库订单信息界面url, 必须包含http/https
  zhongxingOutboundUrl: "http://172.26.66.241/#/order-manage/outbound",  // 中兴出库订单信息界面url, 必须包含http/https
}

window.configForWcs = config